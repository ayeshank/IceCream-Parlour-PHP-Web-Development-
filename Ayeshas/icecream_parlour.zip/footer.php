<!DOCTYPE html>
<html lang="en">
<head> 
    <style>
    </style>
</head>
<body>
<br><br><br><br><br><br>
<div style="background-color:pink;padding:35px;" id="footdiv">
<table style="width:87%;margin-right:50%;" id="foot">
          
            <th>
            <h1 style="text-align:center;">Creamello</h1>
            </th>
              <th >
              <h1 style="text-align:center;">Find Us On</h1>
              </th>
              <th>
              <h1 style="text-align:center;">Address</h1>
              </th>     
<tr>
<td id="foottd">
<p style="font-size:large;text-align:center;" id="footp">Get the most of your pleasures with the eye tempting<br> pieces of strawberry combined with delicious<br> strawberry icecreams</p>
</td>
<td id="foottd">
<a href=""  style="color:black;margin-left:30%;">Instagram</a><br>
<a href=""  style="color:black;margin-left:30.5%;">Facebook</a><br>
<a href=""  style="color:black;margin-left:33%;">Twitter</a>
</td>
<td id="foottd">
<p style="font-size:large;text-align:center;" id="footp">151 The Amazing Road<br>Premier Building<br>Manchester<br>400105</p>
</td>
</tr>
</table>
</div>
</body>
</head>