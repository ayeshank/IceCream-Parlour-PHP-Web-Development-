<!DOCTYPE html>
<html lang="en">
<head>
    <title>Icecream Parlour</title>
    <link rel="stylesheet" href="menu1.css">

</head>
<body>
<div>
 <img src="logo.png" style="margin-left:5%" >
 <a href="user.php" style="margin-left:65%"><img src="user.png" id="user"></a>
<a href="bucket.php"><img src="supermarket.png" id="market"></a><br><br>
<div style="background-image: linear-gradient(to top,white, rgba(136, 13, 13, 0.959));padding:20px">
<div id="mynavbar">
 <a href="home.php" class="mynavbar">Home</a> 
<a href="#" class="mynavbar">About</a> 
<a href="products.php" class="mynavbar">Products</a> 
<a href="#" class="mynavbar">Get in touch</a>
</div>
</div>
</div>

</body>
</html>